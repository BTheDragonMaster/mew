#!/usr/bin/env python

import argparse

from mew.machine_learning.datasets import *

def make_parser():
    parser = argparse.ArgumentParser(description="Train and cross-validate one or more classifiers on sequence and flow data.")

    parser.add_argument('-s', '--sequence_data', required=True, type=str, help="Tab-separated file with sequence ID in the left column and sequence in the right column.")
    parser.add_argument('-e', '--expression_data', required=True, type=str, help="Tab-separated file with sequence ID in the left column and normalised expression in the right column.")
    parser.add_argument('-u', '--utr_data', type=str, default='', help="Two-line file, with the 5' UTR on the first line and the 3' UTR on the second line.")
    parser.add_argument('-o', '--output_folder', default=os.path.join(os.getcwd(), 'cross-validation'), type=str, help="Output folder for saving cross-validation data.")
    parser.add_argument('-f', '--fold', default=10, type=int, help="Supply x for x-fold cross-validation.")
    parser.add_argument('-n', '--name', required=True, type=str, help="Name for analysis")

    ml_methods = parser.add_mutually_exclusive_group(required=True)
    ml_methods.add_argument('-l', '--lasso', action='store_true', help="Do cross-validation for LASSO regressor.")
    ml_methods.add_argument('-rf', '--random_forest', action='store_true', help="Do cross-validation for random forest regressor.")
    ml_methods.add_argument('-lr', '--linear_regression', action='store_true', help="Do cross-validation for linear regression.")
    ml_methods.add_argument('-nn', '--neural_net', action='store_true', help="Do cross-validation for neural net regressor.")

    featurisation_methods = parser.add_mutually_exclusive_group(required=True)
    featurisation_methods.add_argument('-ob', '--onehot_base', action='store_true', help="Use one-hot encoding of bases for featurisation.")
    featurisation_methods.add_argument('-oc', '--onehot_codon', action='store_true', help="Use one-hot encoding of codons for featurisation.")
    featurisation_methods.add_argument('-bpp', '--base_pairing_probabilities', action='store_true', help="Use base-pairing probabilities derived from mRNA secondary structure for featurisation.")

    return parser

def get_featurisation(args):

    featurisation = None

    if args.onehot_base:
        featurisation = 'base'
    elif args.onehot_codon:
        featurisation = 'codon'
    elif args.base_pairing_probabilities:
        featurisation = 'rna-bppm-totals'

    return featurisation

def get_algorithm(args):
    algorithm = None

    if args.lasso:
        algorithm = 'lasso'
    elif args.random_forest:
        algorithm = 'random_forest'
    elif args.linear_regression:
        algorithm = 'linear_regression'
    elif args.neural_net:
        algorithm = 'neural_net'

    return algorithm

def do_crossval(args):
    encoding = get_featurisation(args)
    algorithm = get_algorithm(args)
    dataset = build_dataset(args.sequence_data, args.expression_data, args.name, encoding, 'crossval', utr_file=args.utr_data, fold=args.fold, algorithm=algorithm)
    dataset.initialise_groups()
    dataset.populate_groups()
    dataset.do_crossval(args.output_folder)
    dataset.plot_actual_vs_predicted()

if __name__ == "__main__":
    parser = make_parser()
    args = parser.parse_args()
    do_crossval(args)









