from mew.featurisation.viennarna import *
from mew.featurisation.viennarna import from_bppm_base_totals
from mew.featurisation.one_hot import do_onehot_encoding

class DataPoint:

    def __init__(self, well, sequence, flow, encoding, five_utr='', terminator=''):
        self.flow = flow
        self.well = well
        self.sequence = sequence
        self.five_utr = five_utr
        self.terminator = terminator
        self.encoding = encoding

        self.feature_vector = []
        self.feature_mapping = {}

        self.encode()

    def __repr__(self):
        return self.well

    def __hash__(self):
        return self.well

    def encode(self):
        if self.encoding == 'rna-bppm-totals':
            self.feature_vector = from_bppm_base_totals(self.sequence, self.five_utr, self.terminator)
        elif self.encoding == 'one-hot-base':
            self.feature_vector = do_onehot_encoding(self.sequence, type='base')
        elif self.encoding == 'one-hot-codon':
            self.feature_vector = do_onehot_encoding(self.sequence, type='codon')


    def set_crossval_predicted_flow(self, flow):
        self.predicted_flow = flow
        self.difference = abs(self.predicted_flow - self.flow)